# SnakeRL
A Multi Agent Reinforcement Learning environment